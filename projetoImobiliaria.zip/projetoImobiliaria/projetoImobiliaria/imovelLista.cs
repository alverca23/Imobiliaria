﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BusinessLogicLayer;

namespace projetoImobiliaria
{
    public partial class imovelLista : Form
    {
        public imovelLista()
        {
            InitializeComponent();
        }

        private void imovelLista_Load(object sender, EventArgs e)
        {
            DataTable dt = BLL.Imoveis.Load();

            dataGridView1.DataSource = dt;

            dataGridView1.RowTemplate.MinimumHeight = 35;

            dataGridView1.RowHeadersWidth = 4;
        }
    }
}
