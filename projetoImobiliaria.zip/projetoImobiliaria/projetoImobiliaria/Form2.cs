﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BusinessLogicLayer;

namespace projetoImobiliaria
{
    public partial class FormSalarios : Form
    {
        public FormSalarios()
        {
            InitializeComponent();
        }

        private void FormSalarios_Load(object sender, EventArgs e)
        {
            dataGridView1.DataSource = BLL.Funcionarios.SalariosLoad();

            dataGridView1.RowTemplate.MinimumHeight = 35;

            dataGridView1.RowHeadersWidth = 4;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            dataGridView1.DataSource = BLL.Funcionarios.Pesquisarfuncionario(textBox1.Text);
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            textBox2.Text = dataGridView1.Rows[e.RowIndex].Cells["Salario"].Value.ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (String.IsNullOrEmpty(textBox2.Text))
            {
                MessageBox.Show("Tem de inserir um valor!", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                BLL.Funcionarios.Update_Salarios(Convert.ToInt32(dataGridView1.Rows[dataGridView1.CurrentRow.Index].Cells[0].Value), Convert.ToInt32(textBox2.Text));

                dataGridView1.DataSource = BLL.Funcionarios.SalariosLoad();

                textBox2.Clear();
            }
        }
    }
}
