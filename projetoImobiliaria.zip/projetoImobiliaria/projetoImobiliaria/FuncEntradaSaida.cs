﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BusinessLogicLayer;

namespace projetoImobiliaria
{
    public partial class FuncEntradaSaida : Form
    {
        public FuncEntradaSaida()
        {
            InitializeComponent();
        }

        private void FuncEntradaSaida_Load(object sender, EventArgs e)
        {
            dataGridView1.DataSource = BLL.Calendario.Load();

            // DataGridView Design
            dataGridView1.RowTemplate.MinimumHeight = 35;
            dataGridView1.RowHeadersWidth = 4;
        }
    }
}
