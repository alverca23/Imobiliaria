﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BusinessLogicLayer;
using System.IO;

namespace projetoImobiliaria
{
    public partial class Form4 : Form
    {
        Image imagem;
        byte[] imgbd;

        public Form4()
        {
            InitializeComponent();
        }

        private void Form4_Load(object sender, EventArgs e)
        {
            this.Size = new Size(Screen.PrimaryScreen.Bounds.Width, Screen.PrimaryScreen.Bounds.Height);

            dataGridView1.DataSource = BLL.Funcionarios.Load1();

            dataGridView1.RowTemplate.MinimumHeight = 35;

            dataGridView1.RowHeadersWidth = 4;
        }

        public byte[] imgToByteArray(Image img)
        {
            using (MemoryStream mStream = new MemoryStream())
            { 
                img.Save(mStream, img.RawFormat);
                return mStream.ToArray();
            }
        }

        public static byte[] ImageToByte(Image img)
        {
            ImageConverter converter = new ImageConverter();
            return (byte[])converter.ConvertTo(img, typeof(byte[]));
        }

        public Image byteArrayToImage(byte[] byteArrayIn)
        {
            using (MemoryStream mStream = new MemoryStream(byteArrayIn))
            {
                return Image.FromStream(mStream);
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            label1.Text = this.Width + " " + this.Height;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //bool existe = false;

            foreach (DataGridViewRow row in dataGridView1.Rows)
            {
                if (Convert.ToInt32(row.Cells[0].Value) == Convert.ToInt32(textBox1.Text))
                {
                    MessageBox.Show("Já existe um Funcionário com esse Id", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);

                    //existe = true;

                    foreach (var txtitem in this.Controls.OfType<TextBox>())
                    {
                        txtitem.Clear();
                    }
                }
            }
            if (String.IsNullOrEmpty(textBox1.Text) || String.IsNullOrEmpty(textBox2.Text) || String.IsNullOrEmpty(textBox3.Text) || String.IsNullOrEmpty(textBox4.Text) || String.IsNullOrEmpty(textBox5.Text) || String.IsNullOrEmpty(textBox6.Text) || String.IsNullOrEmpty(textBox7.Text))
            {
                MessageBox.Show("Tem de preencher os campos", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                if (pictureBox1.Image != null)
                {
                    imgbd = imgToByteArray(pictureBox1.Image);
                    BLL.Funcionarios.register(Convert.ToInt32(textBox1.Text), textBox2.Text, textBox3.Text, textBox4.Text, textBox5.Text, textBox6.Text, Convert.ToInt32(textBox7.Text), imgbd, true);
                }
                else
                {
                    imgbd = imgToByteArray(new Bitmap(@"C:\Users\franc\OneDrive\programação\2º ANO\prof beiros\projetoImobiliaria\img\defaultUserImg.png"));
                    BLL.Funcionarios.register(Convert.ToInt32(textBox1.Text), textBox2.Text, textBox3.Text, textBox4.Text, textBox5.Text, textBox6.Text, Convert.ToInt32(textBox7.Text), imgbd, true);
                }

                dataGridView1.DataSource = BLL.Funcionarios.Load1();

            }

            foreach (var txtitem in this.Controls.OfType<TextBox>())
            {
                if (pictureBox1.Image != null)
                {
                    pictureBox1.Image.Dispose();
                    pictureBox1.Image = null;
                }

                txtitem.Clear();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            openFileDialog1.ShowDialog();
            string img = openFileDialog1.FileName;
            pictureBox1.Image = Image.FromFile(img);
            imgbd = imgToByteArray(pictureBox1.Image);
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                textBox1.Text = dataGridView1.Rows[e.RowIndex].Cells["Id"].Value.ToString();
                textBox2.Text = dataGridView1.Rows[e.RowIndex].Cells["Nome"].Value.ToString();
                textBox3.Text = dataGridView1.Rows[e.RowIndex].Cells["Apelido"].Value.ToString();
                textBox4.Text = dataGridView1.Rows[e.RowIndex].Cells["Email"].Value.ToString();
                textBox5.Text = dataGridView1.Rows[e.RowIndex].Cells["Morada"].Value.ToString();
                textBox6.Text = dataGridView1.Rows[e.RowIndex].Cells["NIF"].Value.ToString();
                textBox7.Text = dataGridView1.Rows[e.RowIndex].Cells["Telefone"].Value.ToString();
                byte[] foto = (byte[])dataGridView1.Rows[e.RowIndex].Cells["Foto"].Value;
                pictureBox1.Image = byteArrayToImage(foto);
                imagem = byteArrayToImage(foto);
            }
            
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Image img = pictureBox1.Image; 

            byte[] foto = ImageToByte(img);
            if (String.IsNullOrEmpty(textBox1.Text) || String.IsNullOrEmpty(textBox2.Text) || String.IsNullOrEmpty(textBox3.Text) || String.IsNullOrEmpty(textBox4.Text) || String.IsNullOrEmpty(textBox5.Text) || String.IsNullOrEmpty(textBox6.Text) || String.IsNullOrEmpty(textBox7.Text) || String.IsNullOrEmpty(textBox7.Text))
            {
                MessageBox.Show("Tem selecionar na Tabela uma linha", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning); ;
            }

            else{
                BLL.Funcionarios.Update_funcionario(Convert.ToInt32(textBox1.Text), textBox2.Text, textBox3.Text, textBox4.Text, textBox5.Text, Convert.ToInt32(textBox6.Text), Convert.ToInt32(textBox7.Text), foto);

                dataGridView1.DataSource = BLL.Funcionarios.Load1();
            }
            

            foreach (var txtitem in this.Controls.OfType<TextBox>())
            {
                if (pictureBox1.Image != null)
                {
                    pictureBox1.Image.Dispose();
                    pictureBox1.Image = null;
                }
                txtitem.Clear();
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (String.IsNullOrEmpty(textBox1.Text) || String.IsNullOrEmpty(textBox2.Text) || String.IsNullOrEmpty(textBox3.Text) || String.IsNullOrEmpty(textBox4.Text) || String.IsNullOrEmpty(textBox5.Text) || String.IsNullOrEmpty(textBox6.Text) || String.IsNullOrEmpty(textBox7.Text) || String.IsNullOrEmpty(textBox7.Text))
            {
                MessageBox.Show("Para remover têm de preencher os campos", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning); ;
            }
            else
            {
                BLL.Funcionarios.Desativar_funcionario(Convert.ToInt32(textBox1.Text), false);

                dataGridView1.DataSource = BLL.Funcionarios.Load1();
            }

            foreach (var txtitem in this.Controls.OfType<TextBox>())
            {
                txtitem.Clear();
            }
        }
    }
}
