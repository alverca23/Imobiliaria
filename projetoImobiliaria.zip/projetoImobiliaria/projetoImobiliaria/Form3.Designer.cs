﻿
namespace projetoImobiliaria
{
    partial class main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(main));
            this.xuiFlatMenuStrip1 = new XanderUI.XUIFlatMenuStrip();
            this.clientesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.listarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.adicionarToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.imoveisToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.listarToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.adicionarToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.funcionarioToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.listarToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.gerirToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.salariosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gestaoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.entradasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.agendamentosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.editarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gerirToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.entradaSaidaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sairToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.xuiFlatMenuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // xuiFlatMenuStrip1
            // 
            this.xuiFlatMenuStrip1.BackColor = System.Drawing.Color.DodgerBlue;
            this.xuiFlatMenuStrip1.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xuiFlatMenuStrip1.HoverBackColor = System.Drawing.Color.RoyalBlue;
            this.xuiFlatMenuStrip1.HoverTextColor = System.Drawing.Color.White;
            this.xuiFlatMenuStrip1.ItemBackColor = System.Drawing.Color.DodgerBlue;
            this.xuiFlatMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.clientesToolStripMenuItem,
            this.imoveisToolStripMenuItem,
            this.funcionarioToolStripMenuItem,
            this.gestaoToolStripMenuItem,
            this.agendamentosToolStripMenuItem,
            this.entradaSaidaToolStripMenuItem,
            this.sairToolStripMenuItem});
            this.xuiFlatMenuStrip1.Location = new System.Drawing.Point(0, 0);
            this.xuiFlatMenuStrip1.Name = "xuiFlatMenuStrip1";
            this.xuiFlatMenuStrip1.SelectedBackColor = System.Drawing.Color.DarkOrchid;
            this.xuiFlatMenuStrip1.SelectedTextColor = System.Drawing.Color.White;
            this.xuiFlatMenuStrip1.SeperatorColor = System.Drawing.Color.White;
            this.xuiFlatMenuStrip1.Size = new System.Drawing.Size(800, 33);
            this.xuiFlatMenuStrip1.TabIndex = 0;
            this.xuiFlatMenuStrip1.Text = "xuiFlatMenuStrip1";
            this.xuiFlatMenuStrip1.TextColor = System.Drawing.Color.White;
            // 
            // clientesToolStripMenuItem
            // 
            this.clientesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.listarToolStripMenuItem,
            this.adicionarToolStripMenuItem1});
            this.clientesToolStripMenuItem.ForeColor = System.Drawing.Color.White;
            this.clientesToolStripMenuItem.Name = "clientesToolStripMenuItem";
            this.clientesToolStripMenuItem.Size = new System.Drawing.Size(91, 29);
            this.clientesToolStripMenuItem.Text = "Clientes";
            // 
            // listarToolStripMenuItem
            // 
            this.listarToolStripMenuItem.ForeColor = System.Drawing.Color.White;
            this.listarToolStripMenuItem.Name = "listarToolStripMenuItem";
            this.listarToolStripMenuItem.Size = new System.Drawing.Size(129, 30);
            this.listarToolStripMenuItem.Text = "Listar";
            this.listarToolStripMenuItem.Click += new System.EventHandler(this.listarToolStripMenuItem_Click);
            // 
            // adicionarToolStripMenuItem1
            // 
            this.adicionarToolStripMenuItem1.ForeColor = System.Drawing.Color.White;
            this.adicionarToolStripMenuItem1.Name = "adicionarToolStripMenuItem1";
            this.adicionarToolStripMenuItem1.Size = new System.Drawing.Size(129, 30);
            this.adicionarToolStripMenuItem1.Text = "Gerir";
            this.adicionarToolStripMenuItem1.Click += new System.EventHandler(this.adicionarToolStripMenuItem1_Click);
            // 
            // imoveisToolStripMenuItem
            // 
            this.imoveisToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.listarToolStripMenuItem1,
            this.adicionarToolStripMenuItem2});
            this.imoveisToolStripMenuItem.ForeColor = System.Drawing.Color.White;
            this.imoveisToolStripMenuItem.Name = "imoveisToolStripMenuItem";
            this.imoveisToolStripMenuItem.Size = new System.Drawing.Size(88, 29);
            this.imoveisToolStripMenuItem.Text = "Imoveis";
            // 
            // listarToolStripMenuItem1
            // 
            this.listarToolStripMenuItem1.ForeColor = System.Drawing.Color.White;
            this.listarToolStripMenuItem1.Name = "listarToolStripMenuItem1";
            this.listarToolStripMenuItem1.Size = new System.Drawing.Size(142, 30);
            this.listarToolStripMenuItem1.Text = "Listar";
            this.listarToolStripMenuItem1.Click += new System.EventHandler(this.listarToolStripMenuItem1_Click);
            // 
            // adicionarToolStripMenuItem2
            // 
            this.adicionarToolStripMenuItem2.ForeColor = System.Drawing.Color.White;
            this.adicionarToolStripMenuItem2.Name = "adicionarToolStripMenuItem2";
            this.adicionarToolStripMenuItem2.Size = new System.Drawing.Size(142, 30);
            this.adicionarToolStripMenuItem2.Text = "Gestão";
            this.adicionarToolStripMenuItem2.Click += new System.EventHandler(this.adicionarToolStripMenuItem2_Click);
            // 
            // funcionarioToolStripMenuItem
            // 
            this.funcionarioToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.listarToolStripMenuItem2,
            this.gerirToolStripMenuItem,
            this.salariosToolStripMenuItem});
            this.funcionarioToolStripMenuItem.ForeColor = System.Drawing.Color.White;
            this.funcionarioToolStripMenuItem.Name = "funcionarioToolStripMenuItem";
            this.funcionarioToolStripMenuItem.Size = new System.Drawing.Size(124, 29);
            this.funcionarioToolStripMenuItem.Text = "Funcionário";
            this.funcionarioToolStripMenuItem.Visible = false;
            // 
            // listarToolStripMenuItem2
            // 
            this.listarToolStripMenuItem2.ForeColor = System.Drawing.Color.White;
            this.listarToolStripMenuItem2.Name = "listarToolStripMenuItem2";
            this.listarToolStripMenuItem2.Size = new System.Drawing.Size(150, 30);
            this.listarToolStripMenuItem2.Text = "Listar";
            this.listarToolStripMenuItem2.Click += new System.EventHandler(this.listarToolStripMenuItem2_Click);
            // 
            // gerirToolStripMenuItem
            // 
            this.gerirToolStripMenuItem.ForeColor = System.Drawing.Color.White;
            this.gerirToolStripMenuItem.Name = "gerirToolStripMenuItem";
            this.gerirToolStripMenuItem.Size = new System.Drawing.Size(150, 30);
            this.gerirToolStripMenuItem.Text = "Gerir";
            this.gerirToolStripMenuItem.Click += new System.EventHandler(this.gerirToolStripMenuItem_Click);
            // 
            // salariosToolStripMenuItem
            // 
            this.salariosToolStripMenuItem.ForeColor = System.Drawing.Color.White;
            this.salariosToolStripMenuItem.Name = "salariosToolStripMenuItem";
            this.salariosToolStripMenuItem.Size = new System.Drawing.Size(150, 30);
            this.salariosToolStripMenuItem.Text = "Salarios";
            this.salariosToolStripMenuItem.Click += new System.EventHandler(this.salariosToolStripMenuItem_Click);
            // 
            // gestaoToolStripMenuItem
            // 
            this.gestaoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.entradasToolStripMenuItem});
            this.gestaoToolStripMenuItem.ForeColor = System.Drawing.Color.White;
            this.gestaoToolStripMenuItem.Name = "gestaoToolStripMenuItem";
            this.gestaoToolStripMenuItem.Size = new System.Drawing.Size(82, 29);
            this.gestaoToolStripMenuItem.Text = "Gestão";
            this.gestaoToolStripMenuItem.Visible = false;
            this.gestaoToolStripMenuItem.Click += new System.EventHandler(this.gestaoToolStripMenuItem_Click);
            // 
            // entradasToolStripMenuItem
            // 
            this.entradasToolStripMenuItem.ForeColor = System.Drawing.Color.White;
            this.entradasToolStripMenuItem.Name = "entradasToolStripMenuItem";
            this.entradasToolStripMenuItem.Size = new System.Drawing.Size(180, 30);
            this.entradasToolStripMenuItem.Text = "Entradas";
            this.entradasToolStripMenuItem.Click += new System.EventHandler(this.entradasToolStripMenuItem_Click);
            // 
            // agendamentosToolStripMenuItem
            // 
            this.agendamentosToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.editarToolStripMenuItem,
            this.gerirToolStripMenuItem1});
            this.agendamentosToolStripMenuItem.ForeColor = System.Drawing.Color.White;
            this.agendamentosToolStripMenuItem.Name = "agendamentosToolStripMenuItem";
            this.agendamentosToolStripMenuItem.Size = new System.Drawing.Size(151, 29);
            this.agendamentosToolStripMenuItem.Text = "Agendamentos";
            this.agendamentosToolStripMenuItem.Click += new System.EventHandler(this.agendamentosToolStripMenuItem_Click);
            // 
            // editarToolStripMenuItem
            // 
            this.editarToolStripMenuItem.ForeColor = System.Drawing.Color.White;
            this.editarToolStripMenuItem.Name = "editarToolStripMenuItem";
            this.editarToolStripMenuItem.Size = new System.Drawing.Size(165, 30);
            this.editarToolStripMenuItem.Text = "Gerir";
            this.editarToolStripMenuItem.Click += new System.EventHandler(this.editarToolStripMenuItem_Click);
            // 
            // gerirToolStripMenuItem1
            // 
            this.gerirToolStripMenuItem1.ForeColor = System.Drawing.Color.White;
            this.gerirToolStripMenuItem1.Name = "gerirToolStripMenuItem1";
            this.gerirToolStripMenuItem1.Size = new System.Drawing.Size(165, 30);
            this.gerirToolStripMenuItem1.Text = "Adicionar";
            this.gerirToolStripMenuItem1.Click += new System.EventHandler(this.gerirToolStripMenuItem1_Click);
            // 
            // entradaSaidaToolStripMenuItem
            // 
            this.entradaSaidaToolStripMenuItem.ForeColor = System.Drawing.Color.White;
            this.entradaSaidaToolStripMenuItem.Name = "entradaSaidaToolStripMenuItem";
            this.entradaSaidaToolStripMenuItem.Size = new System.Drawing.Size(142, 29);
            this.entradaSaidaToolStripMenuItem.Text = "Entrada/Saida";
            this.entradaSaidaToolStripMenuItem.Click += new System.EventHandler(this.entradaSaidaToolStripMenuItem_Click);
            // 
            // sairToolStripMenuItem
            // 
            this.sairToolStripMenuItem.ForeColor = System.Drawing.Color.White;
            this.sairToolStripMenuItem.Name = "sairToolStripMenuItem";
            this.sairToolStripMenuItem.Size = new System.Drawing.Size(56, 29);
            this.sairToolStripMenuItem.Text = "Sair";
            this.sairToolStripMenuItem.Click += new System.EventHandler(this.sairToolStripMenuItem_Click);
            // 
            // main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.xuiFlatMenuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.xuiFlatMenuStrip1;
            this.Name = "main";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.main_Load);
            this.xuiFlatMenuStrip1.ResumeLayout(false);
            this.xuiFlatMenuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private XanderUI.XUIFlatMenuStrip xuiFlatMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem clientesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem imoveisToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem funcionarioToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sairToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem listarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem listarToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem listarToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem gestaoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem entradasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem adicionarToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem adicionarToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem gerirToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem salariosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem entradaSaidaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem agendamentosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem editarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem gerirToolStripMenuItem1;
    }
}