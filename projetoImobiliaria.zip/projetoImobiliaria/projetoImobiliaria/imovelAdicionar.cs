﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BusinessLogicLayer;
using System.IO;

namespace projetoImobiliaria
{
    public partial class imovelAdicionar : Form
    {
        Image image;
        byte[] imgbd;

        public imovelAdicionar()
        {
            InitializeComponent();
        }

        private void Form4_Load(object sender, EventArgs e)
        {
            this.Size = new Size(Screen.PrimaryScreen.Bounds.Width, Screen.PrimaryScreen.Bounds.Height);

            dataGridView1.DataSource = BLL.Imoveis.Load();

            dataGridView1.RowTemplate.MinimumHeight = 35;

            dataGridView1.RowHeadersWidth = 4;
        }

        public byte[] imgToByteArray(Image img)
        {
            using (MemoryStream mStream = new MemoryStream())
            { 
                img.Save(mStream, img.RawFormat);
                return mStream.ToArray();
            }
        }

        public static byte[] ImageToByte(Image img)
        {
            ImageConverter converter = new ImageConverter();
            return (byte[])converter.ConvertTo(img, typeof(byte[]));
        }

        public Image byteArrayToImage(byte[] byteArrayIn)
        {
            using (MemoryStream mStream = new MemoryStream(byteArrayIn))
            {
                return Image.FromStream(mStream);
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            label1.Text = this.Width + " " + this.Height;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            bool existe = false;

            foreach (DataGridViewRow row in dataGridView1.Rows)
            {
                if (Convert.ToInt32(row.Cells[0].Value) == Convert.ToInt32(textBox1.Text))
                {
                    MessageBox.Show("Já existe um imovél com esse Id", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);

                    existe = true;

                    foreach (var txtitem in this.Controls.OfType<TextBox>())
                    {
                        txtitem.Clear();                   
                    }
                }
            }

            if (String.IsNullOrEmpty(textBox1.Text))
            {
                MessageBox.Show("Tem de preencher os campos pedidos!", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                if (pictureBox1.Image != null)
                {
                    imgbd = imgToByteArray(pictureBox1.Image);
                    BLL.Imoveis.Inserir_Imoveis(Convert.ToInt32(textBox1.Text), textBox2.Text, textBox3.Text, Convert.ToInt32(textBox4.Text), Convert.ToInt32(textBox5.Text), textBox6.Text, textBox7.Text, Convert.ToInt32(textBox8.Text), Convert.ToInt32(textBox9.Text), textBox10.Text, Convert.ToInt32(textBox11.Text), Convert.ToInt32(textBox12.Text), Convert.ToInt32(textBox13.Text), Convert.ToChar(textBox14.Text), imgbd, true);

                }
                else
                {
        
                    imgbd = imgToByteArray(new Bitmap(@"C:\Users\franc\OneDrive\programação\2º ANO\prof beiros\projetoImobiliaria\img\default.jpg"));
                    BLL.Imoveis.Inserir_Imoveis(Convert.ToInt32(textBox1.Text), textBox2.Text, textBox3.Text, Convert.ToInt32(textBox4.Text), Convert.ToInt32(textBox5.Text), textBox6.Text, textBox7.Text, Convert.ToInt32(textBox8.Text), Convert.ToInt32(textBox9.Text), textBox10.Text, Convert.ToInt32(textBox11.Text), Convert.ToInt32(textBox12.Text), Convert.ToInt32(textBox13.Text), Convert.ToChar(textBox14.Text), imgbd, true);
                    dataGridView1.DataSource = BLL.Imoveis.Load();

                }

                if (textBox4.Text == "") { textBox4.Text = "0"; };
                if (textBox5.Text == "") { textBox5.Text = "0"; };
                if (textBox8.Text == "") { textBox8.Text = "0"; };
                if (textBox9.Text == "") { textBox9.Text = "0"; };
                if (textBox11.Text == "") { textBox11.Text = "0"; };
                if (textBox12.Text == "") { textBox12.Text = "0"; };
                if (textBox13.Text == "") { textBox13.Text = "0"; };                

                foreach (var txtitem in this.Controls.OfType<TextBox>())
                {
                    if (pictureBox1.Image != null)
                    {
                        pictureBox1.Image.Dispose();
                        pictureBox1.Image = null;
                    }

                    txtitem.Clear();
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            openFileDialog1.ShowDialog();
            string img = openFileDialog1.FileName;
            pictureBox1.Image = Image.FromFile(img);
            imgbd = imgToByteArray(pictureBox1.Image);
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                textBox1.Text = dataGridView1.Rows[e.RowIndex].Cells["Id"].Value.ToString();
                textBox2.Text = dataGridView1.Rows[e.RowIndex].Cells["proprietario"].Value.ToString();
                textBox3.Text = dataGridView1.Rows[e.RowIndex].Cells["tipo"].Value.ToString();
                textBox4.Text = dataGridView1.Rows[e.RowIndex].Cells["preco"].Value.ToString();
                textBox5.Text = dataGridView1.Rows[e.RowIndex].Cells["proposta_atual"].Value.ToString();
                textBox6.Text = dataGridView1.Rows[e.RowIndex].Cells["Localidade"].Value.ToString();
                textBox7.Text = dataGridView1.Rows[e.RowIndex].Cells["Estado"].Value.ToString();
                textBox8.Text = dataGridView1.Rows[e.RowIndex].Cells["Area_util"].Value.ToString();
                textBox9.Text = dataGridView1.Rows[e.RowIndex].Cells["Area_Bruta"].Value.ToString();
                textBox10.Text = dataGridView1.Rows[e.RowIndex].Cells["Estado_Habitacao"].Value.ToString();
                textBox11.Text = dataGridView1.Rows[e.RowIndex].Cells["Quartos"].Value.ToString();
                textBox12.Text = dataGridView1.Rows[e.RowIndex].Cells["Casas_Banho"].Value.ToString();
                textBox13.Text = dataGridView1.Rows[e.RowIndex].Cells["Anos_Construcao"].Value.ToString();
                textBox14.Text = dataGridView1.Rows[e.RowIndex].Cells["Certificado_Energetico"].Value.ToString();
                byte[] foto = (byte[])dataGridView1.Rows[e.RowIndex].Cells["Foto"].Value;
                pictureBox1.Image = byteArrayToImage(foto);
            }
            
        }

        private void button3_Click(object sender, EventArgs e)
        {

            if (pictureBox1.Image == null)
            {
                DialogResult r = MessageBox.Show("Não colocou imagem, pretende prosseguir", "Aviso", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

                if (r == DialogResult.Yes)
                {
                    BLL.Imoveis.Atualizar_Imovel(Convert.ToInt32(textBox1.Text), textBox2.Text, textBox3.Text, Convert.ToInt32(textBox4.Text), Convert.ToInt32(textBox5.Text), textBox6.Text, textBox7.Text, Convert.ToInt32(textBox8.Text), Convert.ToInt32(textBox9.Text), textBox10.Text, Convert.ToInt32(textBox11.Text), Convert.ToInt32(textBox12.Text), Convert.ToInt32(textBox13.Text), Convert.ToChar(textBox14.Text), null, true);
                }
            }
            else
            {
                imgbd = imgToByteArray(pictureBox1.Image);

                BLL.Imoveis.Atualizar_Imovel(Convert.ToInt32(textBox1.Text), textBox2.Text, textBox3.Text, Convert.ToInt32(textBox4.Text), Convert.ToInt32(textBox5.Text), textBox6.Text, textBox7.Text, Convert.ToInt32(textBox8.Text), Convert.ToInt32(textBox9.Text), textBox10.Text, Convert.ToInt32(textBox11.Text), Convert.ToInt32(textBox12.Text), Convert.ToInt32(textBox13.Text), Convert.ToChar(textBox14.Text), imgbd, true);
            }

            dataGridView1.DataSource = BLL.Imoveis.Load();

            foreach (var txtitem in this.Controls.OfType<TextBox>())
            {
                if (pictureBox1.Image != null)
                {
                    pictureBox1.Image.Dispose();
                    pictureBox1.Image = null;
                }

                txtitem.Clear();
            }

            //Image img = pictureBox1.Image; 

            //byte[] foto = imgToByteArray(img);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (String.IsNullOrEmpty(textBox1.Text) || String.IsNullOrEmpty(textBox2.Text) || String.IsNullOrEmpty(textBox3.Text) || String.IsNullOrEmpty(textBox4.Text) || String.IsNullOrEmpty(textBox5.Text) || String.IsNullOrEmpty(textBox6.Text) || String.IsNullOrEmpty(textBox7.Text) || String.IsNullOrEmpty(textBox7.Text))
            {
                MessageBox.Show("Para remover tem de preencher os campos", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning); ;
            }
            else
            {
                BLL.Imoveis.Desativar_imovel(Convert.ToInt32(textBox1.Text), false);

                dataGridView1.DataSource = BLL.Imoveis.Load();
            }
            

            foreach (var txtitem in this.Controls.OfType<TextBox>())
            {
                if (pictureBox1.Image != null)
                {
                    pictureBox1.Image.Dispose();
                    pictureBox1.Image = null;
                }

                txtitem.Clear();
            }
        }
    }
}
