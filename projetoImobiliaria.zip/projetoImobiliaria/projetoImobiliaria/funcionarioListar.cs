﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BusinessLogicLayer;

namespace projetoImobiliaria
{
    public partial class funcionarioListar : Form
    {
        public funcionarioListar()
        {
            InitializeComponent();
        }

        private void funcionarioListar_Load(object sender, EventArgs e)
        {
            DataTable dt = BLL.Funcionarios.Load1();

            dataGridView2.DataSource = dt;

            dataGridView2.RowTemplate.MinimumHeight = 35;

            dataGridView2.RowHeadersWidth = 4;
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.Text == "Ativo")
            {
                dataGridView2.DataSource = BLL.Funcionarios.FiltrarFuncionario(true);
            }
            else if (comboBox1.Text == "Inativo")
            {
                dataGridView2.DataSource =  BLL.Funcionarios.FiltrarFuncionario(false);
            }
        }
    }
}
