﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BusinessLogicLayer;

namespace projetoImobiliaria
{
    public partial class main : Form
    {
        public main()
        {
            InitializeComponent();
        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DialogResult r = MessageBox.Show("Tem acerteza que quer sair da aplicação", "Aviso", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

            if (r == DialogResult.Yes)
            {
                Application.Exit();
            }         
        }

        private void main_Load(object sender, EventArgs e)
        {
           if (globais.ADM)
            {
                gestaoToolStripMenuItem.Visible = true;
                funcionarioToolStripMenuItem.Visible = true;
                agendamentosToolStripMenuItem.Visible = true;

            }

            DataTable dt = BLL.Calendario.Load();

            if(dt.Rows.Count > 0)
            {
                for(int i=0; i<dt.Rows.Count; i++)
                {
                    if(dt.Rows[i][0].ToString() == globais.idAtual.ToString())
                    {
                        if(dt.Rows[i][2].ToString() == DateTime.Now.ToShortDateString())
                        {
                            entradaSaidaToolStripMenuItem.Text = "Saída";
                            
                        }
                        else
                        {
                            entradaSaidaToolStripMenuItem.Text = "Entrada";
                            
                        }
                    }
                    else
                    {
                        entradaSaidaToolStripMenuItem.Text = "Entrada";
                    }
                }   
            }
        }

        private void listarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            clienteListar f4 = new clienteListar();
            f4.MdiParent = this;
            f4.Show();

        }

        private void editarToolStripMenuItem1_Click(object sender, EventArgs e)
        {

            ClienteEditar f4 = new ClienteEditar();
            f4.MdiParent = this;
            f4.Show();
            globais.EDT = true;

        }

        private void adicionarToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            ClienteEditar f4 = new ClienteEditar();
            f4.MdiParent = this;
            f4.Show();
            globais.EDT = true;
        }

        private void listarToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            funcionarioListar f4 = new funcionarioListar();
            f4.MdiParent = this;
            f4.Show();
            globais.EDT = true;
        }

        private void salariosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormSalarios formSalarios = new FormSalarios();
            formSalarios.MdiParent = this;
            formSalarios.Show();
            globais.EDT = true;
        }

        private void gerirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form4 form4 = new Form4();
            form4.MdiParent = this;
            form4.Show();
            globais.EDT = true;
        }

        private void listarToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            imovelLista imovelLista = new imovelLista();
            imovelLista.MdiParent = this;
            imovelLista.Show();
            globais.EDT = true;
        }

        private void adicionarToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            imovelAdicionar imovelAdicionar = new imovelAdicionar();
            imovelAdicionar.MdiParent = this;
            imovelAdicionar.Show();
            globais.EDT = true;
        }

        private void entradaSaidaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (entradaSaidaToolStripMenuItem.Text == "Entrada")
            {
                BLL.Calendario.EntradaFunc(globais.idAtual, globais.contaAtual, DateTime.Now.ToShortDateString(), DateTime.Now.ToShortTimeString());
            }
            else if (entradaSaidaToolStripMenuItem.Text == "Saída")
            {
                TimeSpan wTime;
                DataTable dt = BLL.Calendario.GetTodayEntrance(globais.idAtual, DateTime.Now.ToShortDateString());

                DateTime entrada = Convert.ToDateTime(dt.Rows[0][0].ToString());
                DateTime saida = Convert.ToDateTime(DateTime.Now.ToShortTimeString());

                wTime = saida - entrada;

                BLL.Calendario.SaidaFunc(globais.idAtual, DateTime.Now.ToShortDateString(), DateTime.Now.ToShortTimeString(), wTime.ToString());
            }

            
        }

        private void agendamentosToolStripMenuItem_Click(object sender, EventArgs e)
        {
        
        }

        private void editarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            agendamentose agendamentose = new agendamentose();
            agendamentose.MdiParent = this;
            agendamentose.Show();
            globais.EDT = true;

        }

        private void gerirToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            agendamentos agendamentos = new agendamentos();
            agendamentos.MdiParent = this;
            agendamentos.Show();
            globais.EDT = true;
        }

        private void gestaoToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void entradasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (globais.ADM)
            {
                FuncEntradaSaida FuncEntradaSaida = new FuncEntradaSaida();
                FuncEntradaSaida.MdiParent = this;
                FuncEntradaSaida.Show();
                globais.EDT = true;
            }
        }
    }
}
