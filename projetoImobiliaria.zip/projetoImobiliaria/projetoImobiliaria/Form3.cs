﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace projetoImobiliaria
{
    public partial class main : Form
    {
        public main()
        {
            InitializeComponent();
        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DialogResult r = MessageBox.Show("Tem a certeza que pretende sair da aplicação", "Aplicação", MessageBoxButtons.YesNo);
            
            if (r == DialogResult.Yes)
            {
                Application.Exit();
            }         
        }

        private void clientesToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void main_Load(object sender, EventArgs e)
        {
            if (globais.ADM)
            {
                funcionarioToolStripMenuItem.Visible=true;
                gestaoToolStripMenuItem.Visible = true;
            }
          
        }

        private void listarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            clienteListar f4 = new clienteListar();
            f4.MdiParent = this;
            f4.Show();

        }

        private void editarToolStripMenuItem1_Click(object sender, EventArgs e)
        {

            ClienteEditar f4 = new ClienteEditar();
            f4.MdiParent = this;
            f4.Show();
            globais.EDT = true;

        }

        private void adicionarToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            ClienteEditar f4 = new ClienteEditar();
            f4.MdiParent = this;
            f4.Show();
            globais.EDT = true;
        }

        private void listarToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            funcionarioListar f4 = new funcionarioListar();
            f4.MdiParent = this;
            f4.Show();
            globais.EDT = true;
        }

        private void funcionarioToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void salariosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormSalarios formSalarios = new FormSalarios();
            formSalarios.MdiParent = this;
            formSalarios.Show();
            globais.EDT = true;
        }
    }
}
