﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace projetoImobiliaria
{
    class globais
    {
        public static bool ADM = false;
        public static bool EDT = false;
        public static bool IMOEDT = false;
        public static int idAtual;
        public static string contaAtual;
    }
}
